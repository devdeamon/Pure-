import React, { useMemo, useRef, useState } from "react";
import { View, Text, Pressable } from "react-native";
import BottomSheet, { BottomSheetBackdrop } from "@gorhom/bottom-sheet";
import Slider from "@react-native-community/slider";
import { useAppStore } from "../state/appStore";
import { useI18n } from "../utils/i18n";

interface FiltersSheetProps {
  open: boolean;
  onClose: () => void;
}

export default function FiltersSheet({ open, onClose }: FiltersSheetProps) {
  const { t } = useI18n();
  const sheetRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ["50%", "85%"], []);
  const filters = useAppStore((s) => s.filters);
  const setFilters = useAppStore((s) => s.setFilters);
  const resetFilters = useAppStore((s) => s.resetFilters);

  const [localAge, setLocalAge] = useState<[number, number]>(filters.ageRange);
  const [localRadius, setLocalRadius] = useState<number>(filters.radiusKm);

  React.useEffect(() => {
    if (open) sheetRef.current?.expand();
    else sheetRef.current?.close();
  }, [open]);

  return (
    <BottomSheet
      ref={sheetRef}
      index={open ? 1 : -1}
      snapPoints={snapPoints}
      enablePanDownToClose
      backdropComponent={(p) => <BottomSheetBackdrop {...p} appearsOnIndex={0} disappearsOnIndex={-1} />}
      onClose={onClose}
      backgroundStyle={{ backgroundColor: "#111" }}
      handleIndicatorStyle={{ backgroundColor: "#333" }}
    >
      <View className="px-5 py-3">
        <Text className="text-white text-xl font-semibold mb-2">{t("filters.title")}</Text>
        <Text className="text-gray-400 mb-4">{t("filters.subtitle")}</Text>

        {/* Age Range */}
        <View className="mb-4">
          <Text className="text-white mb-2">{t("filters.age")}: {localAge[0]} - {localAge[1]}</Text>
          <Slider
            minimumValue={18}
            maximumValue={60}
            step={1}
            value={localAge[0]}
            onValueChange={(v) => setLocalAge(([_, b]) => [Math.min(v, b - 1), b])}
            minimumTrackTintColor="#ff4458"
            maximumTrackTintColor="#333"
          />
          <Slider
            minimumValue={19}
            maximumValue={60}
            step={1}
            value={localAge[1]}
            onValueChange={(v) => setLocalAge(([a, _]) => [a, Math.max(v, a + 1)])}
            minimumTrackTintColor="#ff4458"
            maximumTrackTintColor="#333"
          />
        </View>

        {/* Radius */}
        <View className="mb-4">
          <Text className="text-white mb-2">{t("filters.radius")}: {localRadius} km</Text>
          <Slider
            minimumValue={1}
            maximumValue={100}
            step={1}
            value={localRadius}
            onValueChange={(v) => setLocalRadius(v)}
            minimumTrackTintColor="#ff4458"
            maximumTrackTintColor="#333"
          />
          {localRadius < 5 && (
            <Text className="text-yellow-400 mt-1 text-xs">{t("filters.pro_radius_hint")}</Text>
          )}
        </View>

        {/* Verified only */}
        <View className="mb-4">
          <Pressable
            className={`px-4 py-3 rounded-xl ${filters.verifiedOnly ? "bg-red-500" : "bg-gray-800"}`}
            onPress={() => setFilters({ verifiedOnly: !filters.verifiedOnly })}
          >
            <Text className="text-white">{t("filters.verifiedOnly")}</Text>
          </Pressable>
        </View>

        {/* Ghost mode */}
        <View className="mb-6">
          <Pressable
            className={`px-4 py-3 rounded-xl ${filters.ghostMode ? "bg-red-500" : "bg-gray-800"}`}
            onPress={() => setFilters({ ghostMode: !filters.ghostMode })}
          >
            <Text className="text-white">{t("filters.ghostMode")}</Text>
          </Pressable>
        </View>

        {/* Footer Buttons */}
        <View className="flex-row">
          <Pressable
            className="flex-1 bg-gray-800 py-3 rounded-xl mr-2"
            onPress={() => {
              resetFilters();
              setLocalAge([18, 35]);
              setLocalRadius(25);
            }}
          >
            <Text className="text-white text-center font-semibold">{t("filters.reset")}</Text>
          </Pressable>
          <Pressable
            className="flex-1 bg-red-500 py-3 rounded-xl ml-2"
            onPress={() => {
              setFilters({ ageRange: localAge, radiusKm: localRadius });
              onClose();
            }}
          >
            <Text className="text-white text-center font-semibold">{t("filters.apply")}</Text>
          </Pressable>
        </View>
      </View>
    </BottomSheet>
  );
}
