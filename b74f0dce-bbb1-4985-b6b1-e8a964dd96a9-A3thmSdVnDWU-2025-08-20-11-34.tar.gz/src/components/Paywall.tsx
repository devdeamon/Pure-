import React from "react";
import { View, Text, Pressable } from "react-native";
import { useI18n } from "../utils/i18n";
import { telegramWebApp } from "../utils/telegram";
import { createPayment } from "../api/payments";
import { useAppStore } from "../state/appStore";

interface PaywallProps {
  onClose: () => void;
}

export default function Paywall({ onClose }: PaywallProps) {
  const { t } = useI18n();
  const grantCoins = useAppStore((s) => s.grantCoins);
  const startBoost = useAppStore((s) => s.startBoost);
  const setSubscription = useAppStore((s) => s.setSubscription);

  const buyCoins = async () => {
    const { invoice_url } = await createPayment({ type: "coins", sku: "coins_10" });
    telegramWebApp.openLink(invoice_url);
    grantCoins(10);
    onClose();
  };

  const buyBoost = async () => {
    const { invoice_url } = await createPayment({ type: "boost", sku: "boost_2h" });
    telegramWebApp.openLink(invoice_url);
    startBoost(120);
    onClose();
  };

  const buySub = async () => {
    const { invoice_url } = await createPayment({ type: "subscription", sku: "pro_month" });
    telegramWebApp.openLink(invoice_url);
    setSubscription(true);
    onClose();
  };

  return (
    <View className="bg-gray-900 rounded-2xl p-5 mx-6">
      <Text className="text-white text-xl font-semibold mb-1">{t("paywall.title")}</Text>
      <Text className="text-gray-400 mb-4">{t("paywall.subtitle")}</Text>

      <Pressable className="bg-red-500 rounded-xl px-4 py-3 mb-3" onPress={buyCoins}>
        <Text className="text-white text-center font-semibold">{t("paywall.buyCoins")}</Text>
      </Pressable>
      <Pressable className="bg-blue-500 rounded-xl px-4 py-3 mb-3" onPress={buyBoost}>
        <Text className="text-white text-center font-semibold">{t("paywall.buyBoost")}</Text>
      </Pressable>
      <Pressable className="bg-gray-800 rounded-xl px-4 py-3" onPress={buySub}>
        <Text className="text-white text-center font-semibold">{t("paywall.buySub")}</Text>
      </Pressable>

      <Pressable className="mt-4" onPress={onClose}>
        <Text className="text-gray-400 text-center">Close</Text>
      </Pressable>
    </View>
  );
}
