import React from "react";
import { View, Text, Image, Dimensions } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { UserProfile } from "../state/userStore";

const { width: screenWidth } = Dimensions.get("window");
const CARD_WIDTH = screenWidth - 40;

interface ProfileCardProps {
  profile: UserProfile;
}

export default function ProfileCard({ profile }: ProfileCardProps) {
  const getAgeFromBirthdate = (age: number) => age;
  
  const getPurposeIcon = (purpose: string) => {
    switch (purpose) {
      case "dating": return "heart";
      case "friends": return "people";
      case "networking": return "briefcase";
      default: return "person";
    }
  };

  return (
    <View 
      className="bg-gray-900 rounded-2xl overflow-hidden shadow-lg"
      style={{ width: CARD_WIDTH, height: CARD_WIDTH * 1.3 }}
    >
      {/* Main Photo */}
      <View className="flex-1 relative">
        {profile.photos.length > 0 ? (
          <Image
            source={{ uri: profile.photos[0] }}
            className="w-full h-full"
            resizeMode="cover"
          />
        ) : (
          <View className="w-full h-full bg-gray-800 items-center justify-center">
            <Ionicons name="person" size={80} color="#666" />
          </View>
        )}
        
        {/* Verification Badge */}
        {profile.isVerified && (
          <View className="absolute top-4 right-4 bg-blue-500 rounded-full p-2">
            <Ionicons name="checkmark" size={16} color="white" />
          </View>
        )}

        {/* Photo Indicators */}
        {profile.photos.length > 1 && (
          <View className="absolute top-4 left-4 flex-row">
            {profile.photos.map((_, index) => (
              <View
                key={index}
                className={`w-2 h-2 rounded-full mx-1 ${
                  index === 0 ? "bg-white" : "bg-white/30"
                }`}
              />
            ))}
          </View>
        )}
      </View>

      {/* Profile Info */}
      <View className="p-4">
        <View className="flex-row items-center justify-between mb-2">
          <View className="flex-row items-center">
            <Text className="text-white text-xl font-bold">
              {profile.name}
            </Text>
            <Text className="text-gray-400 text-xl ml-2">
              {getAgeFromBirthdate(profile.age)}
            </Text>
          </View>
          
          <View className="flex-row items-center">
            <Ionicons 
              name={getPurposeIcon(profile.purpose) as any} 
              size={16} 
              color="#ff4458" 
            />
            <Text className="text-gray-400 text-sm ml-1 capitalize">
              {profile.purpose}
            </Text>
          </View>
        </View>

        {/* Location */}
        <View className="flex-row items-center mb-3">
          <Ionicons name="location-outline" size={14} color="#666" />
          <Text className="text-gray-400 text-sm ml-1">
            {profile.city}
          </Text>
        </View>

        {/* Interests */}
        {profile.interests.length > 0 && (
          <View className="flex-row flex-wrap">
            {profile.interests.slice(0, 3).map((interest, index) => (
              <View
                key={index}
                className="bg-gray-800 px-3 py-1 rounded-full mr-2 mb-1"
              >
                <Text className="text-gray-300 text-xs">
                  {interest}
                </Text>
              </View>
            ))}
            {profile.interests.length > 3 && (
              <View className="bg-gray-800 px-3 py-1 rounded-full">
                <Text className="text-gray-300 text-xs">
                  +{profile.interests.length - 3}
                </Text>
              </View>
            )}
          </View>
        )}

        {/* Bio */}
        {profile.bio && (
          <Text className="text-gray-300 text-sm mt-2" numberOfLines={2}>
            {profile.bio}
          </Text>
        )}
      </View>
    </View>
  );
}