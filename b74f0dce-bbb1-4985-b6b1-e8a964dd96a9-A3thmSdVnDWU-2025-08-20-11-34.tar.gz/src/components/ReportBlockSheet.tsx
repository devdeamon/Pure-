import React, { useMemo, useRef, useState } from "react";
import { View, Text, Pressable } from "react-native";
import BottomSheet, { BottomSheetBackdrop } from "@gorhom/bottom-sheet";
import { useI18n } from "../utils/i18n";
import { sendReport } from "../api/moderation";

interface Props {
  open: boolean;
  onClose: () => void;
  targetUserId: string;
}

export default function ReportBlockSheet({ open, onClose, targetUserId }: Props) {
  const { t } = useI18n();
  const sheetRef = useRef<BottomSheet>(null);
  const snapPoints = useMemo(() => ["45%"], []);
  const [sent, setSent] = useState(false);

  React.useEffect(() => {
    if (open) sheetRef.current?.expand();
    else sheetRef.current?.close();
  }, [open]);

  const report = async (reason: string) => {
    await sendReport(targetUserId, reason);
    setSent(true);
    setTimeout(onClose, 800);
  };

  return (
    <BottomSheet
      ref={sheetRef}
      index={open ? 0 : -1}
      snapPoints={snapPoints}
      enablePanDownToClose
      backdropComponent={(p) => <BottomSheetBackdrop {...p} appearsOnIndex={0} disappearsOnIndex={-1} />}
      onClose={onClose}
      backgroundStyle={{ backgroundColor: "#111" }}
      handleIndicatorStyle={{ backgroundColor: "#333" }}
    >
      <View className="px-5 py-3">
        <Text className="text-white text-lg font-semibold mb-3">{t("report.title")}</Text>
        {sent ? (
          <Text className="text-green-400">{t("report.sent")}</Text>
        ) : (
          <>
            <Pressable className="bg-gray-800 rounded-xl px-4 py-3 mb-2" onPress={() => report("spam")}> 
              <Text className="text-white">Spam</Text>
            </Pressable>
            <Pressable className="bg-gray-800 rounded-xl px-4 py-3 mb-2" onPress={() => report("nsfw")}>
              <Text className="text-white">NSFW</Text>
            </Pressable>
            <Pressable className="bg-gray-800 rounded-xl px-4 py-3" onPress={() => report("other")}>
              <Text className="text-white">{t("report.report")}</Text>
            </Pressable>
          </>
        )}
      </View>
    </BottomSheet>
  );
}
