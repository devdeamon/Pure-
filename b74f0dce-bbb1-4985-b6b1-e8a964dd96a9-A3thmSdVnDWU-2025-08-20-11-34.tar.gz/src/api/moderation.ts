export function checkNickname(name: string): { ok: boolean; reason?: string } {
  const bad = /https?:|@|\/[a-z0-9]|\d{6,}/i;
  if (bad.test(name)) return { ok: false, reason: "invalid_nickname" };
  return { ok: true };
}

export async function checkPhoto(url: string): Promise<{ ok: boolean; nsfw?: boolean }> {
  // Stub: allow all
  return { ok: true };
}

export async function sendReport(userId: string, reason: string): Promise<{ ok: boolean }> {
  // Stub: accept
  return { ok: true };
}
