export type PaymentType = "coins" | "boost" | "subscription" | "superlike";

export interface CreatePaymentRequest {
  type: PaymentType;
  sku: string;
  amountCents?: number;
  currency?: string;
}

export async function createPayment(req: CreatePaymentRequest): Promise<{ invoice_url: string }> {
  // Stub: return a mock invoice URL. Replace with real backend.
  return { invoice_url: `https://example.com/invoice/${req.type}/${req.sku}` };
}

export async function verifyPayment(paymentId: string): Promise<{ ok: boolean; entitlement?: string }> {
  // Stub: simulate success
  return { ok: true, entitlement: paymentId };
}
