import React, { useEffect } from "react";
import { createNativeStackNavigator } from "@react-navigation/native-stack";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import { Ionicons } from "@expo/vector-icons";

import { useUserStore } from "../state/userStore";
import { useI18n } from "../utils/i18n";
import { telegramWebApp } from "../utils/telegram";
import { deepLinkHandler } from "../utils/deepLinking";

// Screens
import OnboardingScreen from "../screens/OnboardingScreen";
import SwipeScreen from "../screens/SwipeScreen";
import MatchesScreen from "../screens/MatchesScreen";
import ChatScreen from "../screens/ChatScreen";
import ProfileScreen from "../screens/ProfileScreen";
import HubsScreen from "../screens/HubsScreen";
import VerificationScreen from "../screens/VerificationScreen";

export type RootStackParamList = {
  Onboarding: undefined;
  MainTabs: undefined;
  Chat: { matchId: string; userName: string };
  Verification: undefined;
};

export type TabParamList = {
  Swipe: undefined;
  Matches: undefined;
  Profile: undefined;
  Hubs?: undefined;
};

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

function MainTabs() {
  const { t, lang } = useI18n();
  return (
    <Tab.Navigator
      key={`tabs-${lang}`}
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
          let iconName: keyof typeof Ionicons.glyphMap;

          if (route.name === "Swipe") {
            iconName = focused ? "heart" : "heart-outline";
          } else if (route.name === "Matches") {
            iconName = focused ? "chatbubbles" : "chatbubbles-outline";
          } else if (route.name === "Profile") {
            iconName = focused ? "person" : "person-outline";
          } else {
            iconName = "help-outline";
          }

          return <Ionicons name={iconName} size={size} color={color} />;
        },
        tabBarActiveTintColor: "#ff4458",
        tabBarInactiveTintColor: "#666",
        tabBarStyle: {
          backgroundColor: "#000",
          borderTopColor: "#333",
        },
        headerShown: false,
      })}
    >
      <Tab.Screen name="Swipe" component={SwipeScreen} options={{ title: t("tabs.swipe") }} />
      <Tab.Screen name="Matches" component={MatchesScreen} options={{ title: t("tabs.matches") }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{ title: t("tabs.profile") }} />
      
    </Tab.Navigator>
  );
}

export default function AppNavigator() {
  const isOnboarded = useUserStore((state) => state.isOnboarded);
  const { lang } = useI18n();

  useEffect(() => {
    // Handle deep links from Telegram WebApp
    if (telegramWebApp.isAvailable()) {
      const startParam = telegramWebApp.getStartParam();
      if (startParam) {
        deepLinkHandler.parseStartParam(startParam);
        // Deep link handling will be done after navigation is ready
      }
    }
  }, []);

  return (
    <Stack.Navigator
      key={`stack-${lang}`}
      screenOptions={{
        headerShown: false,
        contentStyle: { backgroundColor: "#000" },
      }}
      initialRouteName={isOnboarded ? "MainTabs" : "Onboarding"}
    >
      <Stack.Screen name="Onboarding" component={OnboardingScreen} />
      <Stack.Screen name="MainTabs" component={MainTabs} />
      <Stack.Screen 
        name="Chat" 
        component={ChatScreen}
        options={{
          headerShown: true,
          headerStyle: { backgroundColor: "#000" },
          headerTintColor: "#fff",
          headerTitle: "",
        }}
      />
      <Stack.Screen 
        name="Verification" 
        component={VerificationScreen}
        options={{
          headerShown: true,
          headerStyle: { backgroundColor: "#000" },
          headerTintColor: "#fff",
          headerTitle: "",
          presentation: "modal",
        }}
      />
    </Stack.Navigator>
  );
}