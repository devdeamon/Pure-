import React from "react";
import { View, Text, ScrollView, Pressable, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useUserStore } from "../state/userStore";
import { useSwipeStore } from "../state/swipeStore";
import { useI18n } from "../utils/i18n";
import { useAppStore } from "../state/appStore";
import { telegramWebApp } from "../utils/telegram";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const navigation = (useNavigation() as any);
  const { currentUser, setOnboarded } = useUserStore();
  const { matches, dailySwipes, maxDailySwipes } = useSwipeStore();
  const { t } = useI18n();
  const lang = useAppStore((s) => s.language);
  const setLanguage = useAppStore((s) => s.setLanguage);

  const handleLogout = () => {
    telegramWebApp.showConfirm(t("profile.signOut") + "?", (confirmed) => {
      if (confirmed) {
        telegramWebApp.hapticFeedback("notification", "success");
        setOnboarded(false);
      }
    });
  };

  if (!currentUser) {
    return (
      <View 
        className="flex-1 bg-black items-center justify-center"
        style={{ paddingTop: insets.top }}
      >
        <Text className="text-white text-xl">{t("profile.noProfile")}</Text>
      </View>
    );
  }

  return (
    <View 
      className="flex-1 bg-black"
      style={{ paddingTop: insets.top }}
    >
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View className="px-6 py-4">
          <View className="flex-row items-center justify-between">
            <Text className="text-white text-2xl font-bold">{t("profile.title")}</Text>
            <Pressable>
              <Ionicons name="settings-outline" size={24} color="#666" />
            </Pressable>
          </View>
        </View>

        {/* Language Toggle */}
        <View className="flex-row mx-6 mb-4">
          <Pressable
            className={`flex-1 p-3 mr-2 rounded-xl ${lang === "en" ? "bg-red-500" : "bg-gray-800"}`}
            onPress={() => {
              telegramWebApp.hapticFeedback("selection");
              setLanguage("en");
            }}
          >
            <Text className="text-white text-center font-semibold">{t("profile.english")}</Text>
          </Pressable>
          <Pressable
            className={`flex-1 p-3 ml-2 rounded-xl ${lang === "ru" ? "bg-red-500" : "bg-gray-800"}`}
            onPress={() => {
              telegramWebApp.hapticFeedback("selection");
              setLanguage("ru");
            }}
          >
            <Text className="text-white text-center font-semibold">{t("profile.russian")}</Text>
          </Pressable>
        </View>

        {/* Profile Photo */}
        <View className="items-center mb-6">
          <View className="relative">
            {currentUser.photos.length > 0 ? (
              <Image
                source={{ uri: currentUser.photos[0] }}
                className="w-32 h-32 rounded-full"
              />
            ) : (
              <View className="w-32 h-32 rounded-full bg-gray-800 items-center justify-center">
                <Ionicons name="person" size={48} color="#666" />
              </View>
            )}
            
            {currentUser.isVerified && (
              <View className="absolute -bottom-2 -right-2 bg-blue-500 rounded-full p-2">
                <Ionicons name="checkmark" size={16} color="white" />
              </View>
            )}
          </View>
          
          <Text className="text-white text-2xl font-bold mt-4">
            {currentUser.name}
          </Text>
          <Text className="text-gray-400 text-lg">
            {t("profile.yearsOld", { n: currentUser.age })}
          </Text>
          
          <View className="flex-row items-center mt-2">
            <Ionicons name="location-outline" size={16} color="#666" />
            <Text className="text-gray-400 ml-1">{currentUser.city}</Text>
          </View>
        </View>

        {/* Stats */}
        <View className="flex-row mx-6 mb-6">
          <View className="flex-1 bg-gray-900 rounded-xl p-4 mr-2">
            <Text className="text-red-500 text-2xl font-bold text-center">
              {matches.length}
            </Text>
            <Text className="text-gray-400 text-center text-sm">
              {t("profile.matches")}
            </Text>
          </View>
          
          <View className="flex-1 bg-gray-900 rounded-xl p-4 ml-2">
            <Text className="text-blue-500 text-2xl font-bold text-center">
              {dailySwipes}/{maxDailySwipes}
            </Text>
            <Text className="text-gray-400 text-center text-sm">
              {t("profile.dailySwipes")}
            </Text>
          </View>
        </View>

        {/* Profile Details */}
        <View className="mx-6 mb-6">
          <Text className="text-white text-lg font-semibold mb-4">
            {t("profile.aboutMe")}
          </Text>
          
          <View className="bg-gray-900 rounded-xl p-4 mb-4">
            <View className="flex-row items-center mb-2">
              <Ionicons name="heart" size={16} color="#ff4458" />
              <Text className="text-white ml-3">{t("profile.lookingFor", { who: currentUser.lookingFor })}</Text>
            </View>
            
            <View className="flex-row items-center mb-2">
              <Ionicons name="flag" size={16} color="#ff4458" />
              <Text className="text-white ml-3 capitalize">{currentUser.purpose}</Text>
            </View>
            
            <View className="flex-row items-center">
              <Ionicons name="person" size={16} color="#ff4458" />
              <Text className="text-white ml-3 capitalize">{currentUser.gender}</Text>
            </View>
          </View>

          {/* Interests */}
          {currentUser.interests.length > 0 && (
            <View className="mb-4">
              <Text className="text-white text-base font-semibold mb-3">
                {t("profile.interests")}
              </Text>
              <View className="flex-row flex-wrap">
                {currentUser.interests.map((interest, index) => (
                  <View
                    key={index}
                    className="bg-gray-800 px-3 py-2 rounded-full mr-2 mb-2"
                  >
                    <Text className="text-gray-300 text-sm">
                      {interest}
                    </Text>
                  </View>
                ))}
              </View>
            </View>
          )}

          {/* Bio */}
          {currentUser.bio && (
            <View className="mb-4">
              <Text className="text-white text-base font-semibold mb-3">
                {t("profile.bio")}
              </Text>
              <View className="bg-gray-900 rounded-xl p-4">
                <Text className="text-gray-300">
                  {currentUser.bio}
                </Text>
              </View>
            </View>
          )}
        </View>

        {/* Action Buttons */}
        <View className="mx-6 mb-8">
          <Pressable className="bg-gray-800 rounded-xl p-4 mb-3 flex-row items-center justify-center">
            <Ionicons name="create-outline" size={20} color="white" />
            <Text className="text-white ml-3 font-semibold">{t("profile.edit")}</Text>
          </Pressable>
          
          <Pressable className="bg-blue-500 rounded-xl p-4 mb-3 flex-row items-center justify-center" onPress={() => navigation.navigate("Verification")}>
            <Ionicons name="shield-checkmark" size={20} color="white" />
            <Text className="text-white ml-3 font-semibold">{t("profile.verify")}</Text>
          </Pressable>
          
          <Pressable 
            className="bg-red-500 rounded-xl p-4 flex-row items-center justify-center"
            onPress={handleLogout}
          >
            <Ionicons name="log-out-outline" size={20} color="white" />
            <Text className="text-white ml-3 font-semibold">{t("profile.signOut")}</Text>
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}