import React from "react";
import { View, Text, ScrollView, Pressable, Image } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useSwipeStore } from "../state/swipeStore";
import { useI18n } from "../utils/i18n";
import { telegramWebApp } from "../utils/telegram";

export default function MatchesScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const matches = useSwipeStore((state) => state.matches);
  const { t, tp, timeAgo } = useI18n();

  const handleChatPress = (match: any) => {
    telegramWebApp.hapticFeedback("selection");
    (navigation as any).navigate("Chat", {
      matchId: match.id,
      userName: match.user.name,
    });
  };

  if (matches.length === 0) {
    return (
      <View 
        className="flex-1 bg-black"
        style={{ paddingTop: insets.top }}
      >
        <View className="px-6 py-4">
          <Text className="text-white text-2xl font-bold">{t("matches.title")}</Text>
        </View>
        
        <View className="flex-1 items-center justify-center px-6">
          <Ionicons name="chatbubbles-outline" size={80} color="#666" />
          <Text className="text-white text-xl mt-4 text-center">
            {t("matches.emptyTitle")}
          </Text>
          <Text className="text-gray-400 text-center mt-2">
            {t("matches.emptySubtitle")}
          </Text>
        </View>
      </View>
    );
  }

  return (
    <View 
      className="flex-1 bg-black"
      style={{ paddingTop: insets.top }}
    >
      {/* Header */}
      <View className="px-6 py-4">
        <Text className="text-white text-2xl font-bold">{t("matches.title")}</Text>
        <Text className="text-gray-400 mt-1">
          {tp("matches.count", matches.length, { n: matches.length })}
        </Text>
      </View>

      {/* Matches List */}
      <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
        {matches.map((match) => (
          <Pressable
            key={match.id}
            className="flex-row items-center px-6 py-4 border-b border-gray-800"
            onPress={() => handleChatPress(match)}
          >
            {/* Profile Photo */}
            <View className="relative">
              {match.user.photos.length > 0 ? (
                <Image
                  source={{ uri: match.user.photos[0] }}
                  className="w-16 h-16 rounded-full"
                />
              ) : (
                <View className="w-16 h-16 rounded-full bg-gray-800 items-center justify-center">
                  <Ionicons name="person" size={24} color="#666" />
                </View>
              )}
              
              {/* Verification Badge */}
              {match.user.isVerified && (
                <View className="absolute -bottom-1 -right-1 bg-blue-500 rounded-full p-1">
                  <Ionicons name="checkmark" size={12} color="white" />
                </View>
              )}
            </View>

            {/* Match Info */}
            <View className="flex-1 ml-4">
              <View className="flex-row items-center justify-between">
                <Text className="text-white text-lg font-semibold">
                  {match.user.name}
                </Text>
                <Text className="text-gray-400 text-sm">
                  {timeAgo(match.matchedAt)}
                </Text>
              </View>
              
              {match.lastMessage ? (
                <Text className="text-gray-400 text-sm mt-1" numberOfLines={1}>
                  {match.lastMessage.text}
                </Text>
              ) : (
                <Text className="text-gray-500 text-sm mt-1 italic">
                  Say hello! 👋
                </Text>
              )}
              
              <View className="flex-row items-center mt-1">
                <Ionicons name="location-outline" size={12} color="#666" />
                <Text className="text-gray-500 text-xs ml-1">
                  {match.user.city}
                </Text>
              </View>
            </View>

            {/* Chat Arrow */}
            <Ionicons name="chevron-forward" size={20} color="#666" />
          </Pressable>
        ))}
      </ScrollView>

      {/* New Matches Section */}
      {matches.filter(m => !m.lastMessage).length > 0 && (
        <View className="px-6 py-4 border-t border-gray-800">
          <Text className="text-white text-lg font-semibold mb-3">
            New Matches
          </Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {matches
              .filter(m => !m.lastMessage)
              .map((match) => (
                <Pressable
                  key={`new-${match.id}`}
                  className="mr-4 items-center"
                  onPress={() => handleChatPress(match)}
                >
                  <View className="relative">
                    {match.user.photos.length > 0 ? (
                      <Image
                        source={{ uri: match.user.photos[0] }}
                        className="w-20 h-20 rounded-full border-2 border-red-500"
                      />
                    ) : (
                      <View className="w-20 h-20 rounded-full bg-gray-800 items-center justify-center border-2 border-red-500">
                        <Ionicons name="person" size={28} color="#666" />
                      </View>
                    )}
                    
                    {/* New Match Badge */}
                    <View className="absolute -top-1 -right-1 bg-red-500 rounded-full px-2 py-1">
                      <Text className="text-white text-xs font-bold">NEW</Text>
                    </View>
                  </View>
                  
                  <Text className="text-white text-sm mt-2 text-center">
                    {match.user.name}
                  </Text>
                </Pressable>
              ))}
          </ScrollView>
        </View>
      )}
    </View>
  );
}