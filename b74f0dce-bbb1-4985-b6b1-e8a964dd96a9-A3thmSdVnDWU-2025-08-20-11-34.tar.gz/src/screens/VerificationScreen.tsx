import React, { useRef, useState } from "react";
import { View, Text, Pressable } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useI18n } from "../utils/i18n";
import { CameraView, CameraType, useCameraPermissions } from "expo-camera";

export default function VerificationScreen() {
  const insets = useSafeAreaInsets();
  const { t } = useI18n();
  const [permission, requestPermission] = useCameraPermissions();
  const cameraRef = useRef(null);
  const [facing, setFacing] = useState<CameraType>("front");
  const [step, setStep] = useState<"idle" | "blink" | "turn" | "done">("idle");
  const [submitting, setSubmitting] = useState(false);

  const start = async () => {
    if (!permission?.granted) {
      await requestPermission();
    }
    setStep("blink");
  };

  const captureSequence = async () => {
    setSubmitting(true);
    // Simulate capture & verification
    setTimeout(() => {
      setSubmitting(false);
      setStep("done");
    }, 1500);
  };

  return (
    <View className="flex-1 bg-black" style={{ paddingTop: insets.top }}>
      <View className="px-6 py-4">
        <Text className="text-white text-2xl font-bold">{t("verify.title")}</Text>
        <Text className="text-gray-400 mt-1">{t("verify.subtitle")}</Text>
      </View>

      <View style={{ flex: 1 }}>
        <CameraView
          ref={cameraRef}
          style={{ flex: 1 }}
          facing={facing}
        />
        <View className="absolute top-0 left-0 right-0 bottom-0 z-10 items-center justify-end pb-8">
          {step === "idle" && (
            <Pressable className="bg-red-500 px-6 py-3 rounded-xl" onPress={start}>
              <Text className="text-white font-semibold">{t("verify.start")}</Text>
            </Pressable>
          )}
          {step === "blink" && (
            <Pressable className="bg-gray-800 px-6 py-3 rounded-xl" onPress={() => setStep("turn") }>
              <Text className="text-white">{t("verify.blink")}</Text>
            </Pressable>
          )}
          {step === "turn" && (
            <Pressable className="bg-gray-800 px-6 py-3 rounded-xl" onPress={captureSequence}>
              <Text className="text-white">{t("verify.turn")}</Text>
            </Pressable>
          )}
          {step === "done" && (
            <View className="bg-green-600 px-6 py-3 rounded-xl">
              <Text className="text-white">{t("verify.success")}</Text>
            </View>
          )}
          {submitting && (
            <View className="bg-gray-800 px-6 py-3 rounded-xl mt-3">
              <Text className="text-white">{t("verify.submitting")}</Text>
            </View>
          )}
        </View>
      </View>
    </View>
  );
}
