import React, { useEffect, useState } from "react";
import { View, Text, Pressable, Dimensions } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  runOnJS,
  withSpring,
  interpolate,
} from "react-native-reanimated";
import { Gesture, GestureDetector } from "react-native-gesture-handler";
import { useSwipeStore } from "../state/swipeStore";
import { UserProfile } from "../state/userStore";
import ProfileCard from "../components/ProfileCard";
import { useI18n } from "../utils/i18n";
import { telegramWebApp } from "../utils/telegram";
import FiltersSheet from "../components/FiltersSheet";

const { width: screenWidth } = Dimensions.get("window");
const SWIPE_THRESHOLD = screenWidth * 0.3;

// Mock data for potential matches
const MOCK_PROFILES: UserProfile[] = [
  {
    id: "1",
    name: "Emma",
    age: 25,
    gender: "female",
    lookingFor: "male",
    purpose: "dating",
    photos: ["https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400"],
    city: "New York",
    interests: ["Photography", "Travel", "Coffee"],
    bio: "Love exploring new places and trying new coffee shops ☕",
    isVerified: true,
  },
  {
    id: "2",
    name: "Alex",
    age: 28,
    gender: "male",
    lookingFor: "female",
    purpose: "dating",
    photos: ["https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400"],
    city: "New York",
    interests: ["Fitness", "Music", "Cooking"],
    bio: "Fitness enthusiast and amateur chef 🍳",
    isVerified: false,
  },
  {
    id: "3",
    name: "Sarah",
    age: 26,
    gender: "female",
    lookingFor: "both",
    purpose: "friends",
    photos: ["https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400"],
    city: "New York",
    interests: ["Art", "Books", "Yoga"],
    bio: "Artist looking for creative friends 🎨",
    isVerified: true,
  },
];

export default function SwipeScreen() {
  const insets = useSafeAreaInsets();
  const { 
    potentialMatches, 
    currentCardIndex, 
    dailySwipes, 
    maxDailySwipes,
    setPotentialMatches, 
    incrementSwipes, 
    nextCard,
    addMatch 
  } = useSwipeStore();


  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const rotate = useSharedValue(0);
  const scale = useSharedValue(1);

  const [currentProfile, setCurrentProfile] = useState<UserProfile | null>(null);
  const { t } = useI18n();
  const [banner, setBanner] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);

  useEffect(() => {
    if (potentialMatches.length === 0) {
      setPotentialMatches(MOCK_PROFILES);
    }
  }, []);

  useEffect(() => {
    if (potentialMatches.length > 0 && currentCardIndex < potentialMatches.length) {
      setCurrentProfile(potentialMatches[currentCardIndex]);
    } else {
      setCurrentProfile(null);
    }
  }, [potentialMatches, currentCardIndex]);

  const handleSwipe = (direction: "left" | "right") => {
    if (dailySwipes >= maxDailySwipes) {
      setBanner(t("swipe.limitReached"));
      telegramWebApp.hapticFeedback("notification", "error");
      return;
    }

    // Haptic feedback for swipe
    telegramWebApp.hapticFeedback("impact", direction === "right" ? "medium" : "light");
    
    incrementSwipes();
    
    if (direction === "right" && currentProfile) {
      // Simulate match (30% chance)
      if (Math.random() > 0.7) {
        const match = {
          id: `match_${Date.now()}`,
          user: currentProfile,
          matchedAt: new Date(),
        };
        addMatch(match);
        setBanner(t("chat.matchedWith", { name: currentProfile.name }));
        telegramWebApp.hapticFeedback("notification", "success");
      }
    }

    nextCard();
    resetCard();
  };

  const resetCard = () => {
    translateX.value = withSpring(0);
    translateY.value = withSpring(0);
    rotate.value = withSpring(0);
    scale.value = withSpring(1);
  };

  const panGesture = Gesture.Pan()
    .onStart(() => {
      scale.value = withSpring(0.95);
    })
    .onUpdate((event) => {
      translateX.value = event.translationX;
      translateY.value = event.translationY;
      rotate.value = interpolate(
        event.translationX,
        [-screenWidth, screenWidth],
        [-30, 30]
      );
    })
    .onEnd((event) => {
      scale.value = withSpring(1);
      
      if (Math.abs(event.translationX) > SWIPE_THRESHOLD) {
        const direction = event.translationX > 0 ? "right" : "left";
        translateX.value = withSpring(direction === "right" ? screenWidth : -screenWidth);
        runOnJS(handleSwipe)(direction);
      } else {
        translateX.value = withSpring(0);
        translateY.value = withSpring(0);
        rotate.value = withSpring(0);
      }
    });

  const cardStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      Math.abs(translateX.value),
      [0, SWIPE_THRESHOLD],
      [1, 0.8]
    );

    return {
      transform: [
        { translateX: translateX.value },
        { translateY: translateY.value },
        { rotate: `${rotate.value}deg` },
        { scale: scale.value },
      ],
      opacity,
    };
  });

  const likeOverlayStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      translateX.value,
      [0, SWIPE_THRESHOLD],
      [0, 1]
    );

    return { opacity };
  });

  const passOverlayStyle = useAnimatedStyle(() => {
    const opacity = interpolate(
      translateX.value,
      [-SWIPE_THRESHOLD, 0],
      [1, 0]
    );

    return { opacity };
  });

  if (!currentProfile) {
    return (
      <View 
        className="flex-1 bg-black items-center justify-center"
        style={{ paddingTop: insets.top }}
      >
        <Ionicons name="heart-outline" size={80} color="#666" />
        <Text className="text-white text-xl mt-4">{t("swipe.emptyTitle")}</Text>
        <Text className="text-gray-400 text-center mt-2 px-6">
          {t("swipe.emptySubtitle")}
        </Text>
      </View>
    );
  }

  return (
    <View 
      className="flex-1 bg-black"
      style={{ paddingTop: insets.top }}
    >
      {/* Header */}
      <View className="flex-row items-center justify-between px-6 py-4">
        <View className="flex-row items-center">
          <Ionicons name="flame" size={24} color="#ff4458" />
          <Text className="text-white text-lg font-bold ml-2">{t("app.name")}</Text>
        </View>
        
        <View className="flex-row items-center">
          <Text className="text-gray-400 text-sm">
            {t("swipe.counter", { used: dailySwipes, max: maxDailySwipes })}
          </Text>
          <Pressable className="ml-4" onPress={() => setFiltersOpen(true)}>
            <Ionicons name="options-outline" size={24} color="#666" />
          </Pressable>
        </View>
      </View>

      {banner ? (
        <View className="mx-6 mb-2 bg-gray-900 border border-red-500 rounded-xl p-3">
          <Text className="text-red-400 text-center">{banner}</Text>
        </View>
      ) : null}

      {/* Card Stack */}
      <View className="flex-1 items-center justify-center px-5">
        <GestureDetector gesture={panGesture}>
          <Animated.View style={cardStyle}>
            <ProfileCard profile={currentProfile} />
            
            {/* Like Overlay */}
            <Animated.View 
              className="absolute inset-0 items-center justify-center"
              style={likeOverlayStyle}
            >
              <View className="bg-green-500 px-6 py-3 rounded-2xl border-4 border-green-400">
                <Text className="text-white text-2xl font-bold">{t("swipe.like")}</Text>
              </View>
            </Animated.View>

            {/* Pass Overlay */}
            <Animated.View 
              className="absolute inset-0 items-center justify-center"
              style={passOverlayStyle}
            >
              <View className="bg-red-500 px-6 py-3 rounded-2xl border-4 border-red-400">
                <Text className="text-white text-2xl font-bold">{t("swipe.pass")}</Text>
              </View>
            </Animated.View>
          </Animated.View>
        </GestureDetector>
      </View>

      {/* Action Buttons */}
      <View className="flex-row items-center justify-center pb-8 px-6">
        <Pressable
          className="bg-gray-800 w-16 h-16 rounded-full items-center justify-center mx-4"
          onPress={() => handleSwipe("left")}
        >
          <Ionicons name="close" size={28} color="#ff4458" />
        </Pressable>

        <Pressable className="bg-blue-500 w-12 h-12 rounded-full items-center justify-center mx-2" onPress={() => setBanner(t("paywall.superlike"))}>
          <Ionicons name="star" size={20} color="white" />
        </Pressable>

        <Pressable
          className="bg-gray-800 w-16 h-16 rounded-full items-center justify-center mx-4"
          onPress={() => handleSwipe("right")}
        >
          <Ionicons name="heart" size={28} color="#4ade80" />
        </Pressable>
      </View>
      <FiltersSheet open={filtersOpen} onClose={() => setFiltersOpen(false)} />
    </View>
  );
}