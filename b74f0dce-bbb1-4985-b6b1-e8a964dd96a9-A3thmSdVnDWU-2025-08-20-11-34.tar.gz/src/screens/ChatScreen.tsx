import React, { useState, useRef, useEffect } from "react";
import { 
  View, 
  Text, 
  TextInput, 
  Pressable, 
  ScrollView, 
  KeyboardAvoidingView,
  Platform,
  Keyboard
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useRoute, useNavigation } from "@react-navigation/native";
import { useI18n } from "../utils/i18n";

interface Message {
  id: string;
  text: string;
  senderId: string;
  timestamp: Date;
  isMe: boolean;
}

export default function ChatScreen() {
  const insets = useSafeAreaInsets();
  const route = useRoute();
  const navigation = useNavigation();
  const scrollViewRef = useRef<ScrollView>(null);
  
  const { userName } = route.params as { matchId: string; userName: string };
  const { t } = useI18n();
  
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Hey! Nice to match with you 😊",
      senderId: "other",
      timestamp: new Date(Date.now() - 1000 * 60 * 30),
      isMe: false,
    },
  ]);
  const [inputText, setInputText] = useState("");

  useEffect(() => {
    navigation.setOptions({
      headerTitle: userName,
      headerTitleStyle: { color: "#fff" },
    });
  }, [userName]);

  const sendMessage = () => {
    if (inputText.trim()) {
      const newMessage: Message = {
        id: Date.now().toString(),
        text: inputText.trim(),
        senderId: "me",
        timestamp: new Date(),
        isMe: true,
      };
      
      setMessages(prev => [...prev, newMessage]);
      setInputText("");
      
      // Auto-scroll to bottom
      setTimeout(() => {
        scrollViewRef.current?.scrollToEnd({ animated: true });
      }, 100);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
  };

  const dismissKeyboard = () => {
    Keyboard.dismiss();
  };

  return (
    <KeyboardAvoidingView 
      className="flex-1 bg-black"
      behavior={Platform.OS === "ios" ? "padding" : "height"}
    >
      {/* Messages */}
      <ScrollView
        ref={scrollViewRef}
        className="flex-1 px-4"
        showsVerticalScrollIndicator={false}
        onContentSizeChange={() => scrollViewRef.current?.scrollToEnd({ animated: true })}
        onTouchStart={dismissKeyboard}
      >
        <View className="py-4">
          {/* Match Notification */}
          <View className="items-center mb-6">
            <View className="bg-gray-800 px-4 py-2 rounded-full">
              <Text className="text-gray-400 text-sm">
                {t("chat.matchedWith", { name: userName })}
              </Text>
            </View>
          </View>

          {/* Messages */}
          {messages.map((message) => (
            <View
              key={message.id}
              className={`mb-4 ${message.isMe ? "items-end" : "items-start"}`}
            >
              <View
                className={`max-w-[80%] px-4 py-3 rounded-2xl ${
                  message.isMe
                    ? "bg-red-500 rounded-br-md"
                    : "bg-gray-800 rounded-bl-md"
                }`}
              >
                <Text className="text-white text-base">
                  {message.text}
                </Text>
              </View>
              <Text className="text-gray-500 text-xs mt-1 px-2">
                {formatTime(message.timestamp)}
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>

      {/* Input Area */}
      <View 
        className="flex-row items-center px-4 py-3 border-t border-gray-800"
        style={{ paddingBottom: insets.bottom + 12 }}
      >
        {/* Quick Reactions */}
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false}
          className="mr-3"
        >
          {["👋", "😊", "❤️", "😂", "🔥"].map((emoji) => (
            <Pressable
              key={emoji}
              className="bg-gray-800 w-10 h-10 rounded-full items-center justify-center mr-2"
              onPress={() => {
                const emojiMessage: Message = {
                  id: Date.now().toString(),
                  text: emoji,
                  senderId: "me",
                  timestamp: new Date(),
                  isMe: true,
                };
                setMessages(prev => [...prev, emojiMessage]);
                setTimeout(() => {
                  scrollViewRef.current?.scrollToEnd({ animated: true });
                }, 100);
              }}
            >
              <Text className="text-lg">{emoji}</Text>
            </Pressable>
          ))}
        </ScrollView>

        {/* Text Input */}
        <View className="flex-1 flex-row items-center bg-gray-800 rounded-full px-4 py-2">
          <TextInput
            className="flex-1 text-white text-base"
            placeholder={t("chat.placeholder")}
            placeholderTextColor="#666"
            value={inputText}
            onChangeText={setInputText}
            multiline
            maxLength={500}
            onSubmitEditing={sendMessage}
            returnKeyType="send"
          />
          
          {inputText.trim() && (
            <Pressable
              className="ml-2 bg-red-500 w-8 h-8 rounded-full items-center justify-center"
              onPress={sendMessage}
            >
              <Ionicons name="send" size={16} color="white" />
            </Pressable>
          )}
        </View>

        {/* Voice Message Button */}
        {!inputText.trim() && (
          <Pressable className="ml-3 bg-gray-800 w-10 h-10 rounded-full items-center justify-center">
            <Ionicons name="mic" size={20} color="#666" />
          </Pressable>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}