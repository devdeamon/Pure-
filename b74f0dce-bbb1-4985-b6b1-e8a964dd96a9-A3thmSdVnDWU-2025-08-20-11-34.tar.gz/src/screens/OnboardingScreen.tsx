import React, { useState, useEffect } from "react";
import { View, Text, Pressable, TextInput, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { Ionicons } from "@expo/vector-icons";
import { useNavigation } from "@react-navigation/native";
import { useUserStore } from "../state/userStore";
import * as ImagePicker from "expo-image-picker";
import { useI18n } from "../utils/i18n";
import { telegramWebApp } from "../utils/telegram";

const ONBOARDING_STEPS = 4;

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const navigation = useNavigation();
  const { setOnboarded, setCurrentUser, setTelegramData, telegramData } = useUserStore();
  const { t } = useI18n();
  const [errorText, setErrorText] = useState("");
  
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    name: "",
    age: "",
    gender: "" as "male" | "female" | "other" | "",
    lookingFor: "" as "male" | "female" | "both" | "",
    purpose: "" as "dating" | "friends" | "networking" | "",
    photos: [] as string[],
    city: "",
    interests: [] as string[],
  });

  useEffect(() => {
    // Get real Telegram WebApp data or fallback to mock
    const telegramUser = telegramWebApp.getUser();
    const telegramData = telegramUser || {
      id: 123456789,
      first_name: "John",
      last_name: "Doe",
      username: "johndoe",
      photo_url: "https://via.placeholder.com/150"
    };
    
    setTelegramData(telegramData);
    setFormData(prev => ({
      ...prev,
      name: `${telegramData.first_name} ${telegramData.last_name || ""}`.trim()
    }));

    // Auto-detect language from Telegram
    if (telegramUser?.language_code?.startsWith("ru")) {
      // Set Russian language if user's Telegram is in Russian
      // This would be handled by the app store initialization
    }
  }, []);

  const handleNext = () => {
    telegramWebApp.hapticFeedback("selection");
    if (currentStep < ONBOARDING_STEPS) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const handleBack = () => {
    telegramWebApp.hapticFeedback("selection");
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const completeOnboarding = () => {
    if (!formData.name || !formData.age || !formData.gender || !formData.lookingFor || !formData.purpose) {
      setErrorText(t("onboarding.errorRequired"));
      telegramWebApp.hapticFeedback("notification", "error");
      return;
    }

    telegramWebApp.hapticFeedback("notification", "success");

    const userProfile = {
      id: telegramData?.id?.toString() || "user_" + Date.now(),
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender,
      lookingFor: formData.lookingFor,
      purpose: formData.purpose,
      photos: formData.photos,
      city: formData.city || "Unknown",
      interests: formData.interests,
      isVerified: false,
    };

    setCurrentUser(userProfile);
    setOnboarded(true);
    navigation.navigate("MainTabs" as never);
  };

  const pickImage = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ["images"],
      allowsEditing: true,
      aspect: [3, 4],
      quality: 0.8,
    });

    if (!result.canceled && result.assets[0]) {
      setFormData(prev => ({
        ...prev,
        photos: [...prev.photos, result.assets[0].uri]
      }));
    }
  };

  const renderProgressBar = () => (
    <View className="flex-row justify-between mb-8">
      {Array.from({ length: ONBOARDING_STEPS }, (_, i) => (
        <View
          key={i}
          className={`h-1 flex-1 mx-1 rounded ${
            i < currentStep ? "bg-red-500" : "bg-gray-700"
          }`}
        />
      ))}
    </View>
  );

  const renderStep1 = () => (
    <View className="flex-1">
      <Text className="text-white text-2xl font-bold mb-2">{t("onboarding.basicInfo")}</Text>
      <Text className="text-gray-400 mb-6">{t("onboarding.tellUs")}</Text>
      
      <View className="mb-4">
        <Text className="text-white mb-2">{t("onboarding.name")}</Text>
        <TextInput
          className="bg-gray-900 text-white p-4 rounded-xl"
          value={formData.name}
          onChangeText={(text) => setFormData(prev => ({ ...prev, name: text }))}
          placeholder={t("onboarding.name")}
          placeholderTextColor="#666"
        />
      </View>

      <View className="mb-4">
        <Text className="text-white mb-2">{t("onboarding.age")}</Text>
        <TextInput
          className="bg-gray-900 text-white p-4 rounded-xl"
          value={formData.age}
          onChangeText={(text) => setFormData(prev => ({ ...prev, age: text }))}
          placeholder={t("onboarding.age")}
          placeholderTextColor="#666"
          keyboardType="numeric"
        />
      </View>

      <View className="mb-4">
        <Text className="text-white mb-2">{t("onboarding.gender")}</Text>
        <View className="flex-row">
          {["male", "female", "other"].map((gender) => (
            <Pressable
              key={gender}
              className={`flex-1 p-3 mx-1 rounded-xl ${
                formData.gender === gender ? "bg-red-500" : "bg-gray-900"
              }`}
              onPress={() => setFormData(prev => ({ ...prev, gender: gender as any }))}
            >
              <Text className="text-white text-center capitalize">{gender}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </View>
  );

  const renderStep2 = () => (
    <View className="flex-1">
      <Text className="text-white text-2xl font-bold mb-2">{t("onboarding.lookingFor")}</Text>
      <Text className="text-gray-400 mb-6">{t("onboarding.who")}</Text>
      
      <View className="mb-6">
        <Text className="text-white mb-2">{t("onboarding.genderPref")}</Text>
        <View className="flex-row">
            {[
            { key: "male", label: t("onboarding.men") },
            { key: "female", label: t("onboarding.women") },
            { key: "both", label: t("onboarding.both") }
          ].map((option) => (
            <Pressable
              key={option.key}
              className={`flex-1 p-3 mx-1 rounded-xl ${
                formData.lookingFor === option.key ? "bg-red-500" : "bg-gray-900"
              }`}
              onPress={() => setFormData(prev => ({ ...prev, lookingFor: option.key as any }))}
            >
              <Text className="text-white text-center">{option.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>

      <View className="mb-4">
        <Text className="text-white mb-2">{t("onboarding.purpose")}</Text>
        <View className="space-y-2">
          {[
            { key: "dating", label: "Dating", icon: "heart" },
            { key: "friends", label: "Friends", icon: "people" },
            { key: "networking", label: "Networking", icon: "briefcase" }
          ].map((option) => (
            <Pressable
              key={option.key}
              className={`flex-row items-center p-4 rounded-xl ${
                formData.purpose === option.key ? "bg-red-500" : "bg-gray-900"
              }`}
              onPress={() => setFormData(prev => ({ ...prev, purpose: option.key as any }))}
            >
              <Ionicons 
                name={option.icon as any} 
                size={20} 
                color="white" 
                style={{ marginRight: 12 }}
              />
              <Text className="text-white">{option.label}</Text>
            </Pressable>
          ))}
        </View>
      </View>
    </View>
  );

  const renderStep3 = () => (
    <View className="flex-1">
      <Text className="text-white text-2xl font-bold mb-2">{t("onboarding.photos")}</Text>
      <Text className="text-gray-400 mb-6">{t("onboarding.addPhotosHint")}</Text>
      
      <ScrollView className="flex-1">
        <View className="flex-row flex-wrap">
          {formData.photos.map((_, index) => (
            <View key={index} className="w-1/3 aspect-square p-1">
              <View className="bg-gray-900 rounded-xl flex-1" />
            </View>
          ))}
          
          {formData.photos.length < 6 && (
            <Pressable
              className="w-1/3 aspect-square p-1"
              onPress={pickImage}
            >
              <View className="bg-gray-900 rounded-xl flex-1 items-center justify-center border-2 border-dashed border-gray-600">
                <Ionicons name="add" size={32} color="#666" />
                <Text className="text-gray-400 text-xs mt-1">{t("onboarding.addPhoto")}</Text>
              </View>
            </Pressable>
          )}
        </View>
      </ScrollView>
    </View>
  );

  const renderStep4 = () => (
    <View className="flex-1">
      <Text className="text-white text-2xl font-bold mb-2">{t("onboarding.location")}</Text>
      
      <View className="mb-4">
        <Text className="text-white mb-2">{t("onboarding.city")}</Text>
        <TextInput
          className="bg-gray-900 text-white p-4 rounded-xl"
          value={formData.city}
          onChangeText={(text) => setFormData(prev => ({ ...prev, city: text }))}
          placeholder={t("onboarding.city")}
          placeholderTextColor="#666"
        />
      </View>

      <Pressable className="bg-gray-900 p-4 rounded-xl flex-row items-center">
        <Ionicons name="location" size={20} color="#ff4458" />
        <Text className="text-white ml-3">{t("onboarding.useCurrent")}</Text>
      </Pressable>
    </View>
  );

  const renderCurrentStep = () => {
    switch (currentStep) {
      case 1: return renderStep1();
      case 2: return renderStep2();
      case 3: return renderStep3();
      case 4: return renderStep4();
      default: return renderStep1();
    }
  };

  return (
    <View 
      className="flex-1 bg-black"
      style={{ paddingTop: insets.top }}
    >
      <View className="flex-1 px-6 py-4">
        {renderProgressBar()}
        
        <ScrollView className="flex-1" showsVerticalScrollIndicator={false}>
          {renderCurrentStep()}
        </ScrollView>

        {errorText ? (
          <View className="bg-red-500/20 border border-red-500 rounded-xl p-3 mt-3">
            <Text className="text-red-400 text-center">{errorText}</Text>
          </View>
        ) : null}

        <View className="flex-row justify-between mt-6">
          {currentStep > 1 && (
            <Pressable
              className="bg-gray-800 px-6 py-3 rounded-xl flex-1 mr-2"
              onPress={handleBack}
            >
              <Text className="text-white text-center font-semibold">{t("common.back")}</Text>
            </Pressable>
          )}
          
          <Pressable
            className="bg-red-500 px-6 py-3 rounded-xl flex-1 ml-2"
            onPress={handleNext}
          >
            <Text className="text-white text-center font-semibold">
              {currentStep === ONBOARDING_STEPS ? t("common.complete") : t("common.next")}
            </Text>
          </Pressable>
        </View>
      </View>
    </View>
  );
}