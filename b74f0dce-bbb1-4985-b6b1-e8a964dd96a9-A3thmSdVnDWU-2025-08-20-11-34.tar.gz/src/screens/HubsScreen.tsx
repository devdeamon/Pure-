import React from "react";
import { View, Text, Pressable, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useI18n } from "../utils/i18n";
import { useAppStore } from "../state/appStore";

const ROOMS = [
  { key: "tech", interests: ["Tech", "AI", "Programming"] },
  { key: "music", interests: ["Music", "Guitar", "DJ"] },
  { key: "sport", interests: ["Sport", "Running", "Gym"] },
  { key: "startups", interests: ["Startups", "VC", "Pitching"] },
];

export default function HubsScreen() {
  const insets = useSafeAreaInsets();
  const { t } = useI18n();
  const setFilters = useAppStore((s) => s.setFilters);

  const joinRoom = (room: typeof ROOMS[number]) => {
    setFilters({ interests: room.interests });
  };

  return (
    <View className="flex-1 bg-black" style={{ paddingTop: insets.top }}>
      <View className="px-6 py-4">
        <Text className="text-white text-2xl font-bold">{t("hubs.title")}</Text>
      </View>
      <ScrollView className="flex-1" contentContainerStyle={{ paddingHorizontal: 24 }}>
        {ROOMS.map((r) => (
          <Pressable key={r.key} className="bg-gray-900 rounded-xl p-4 mb-3" onPress={() => joinRoom(r)}>
            <Text className="text-white text-lg font-semibold">{t(`hubs.${r.key}`)}</Text>
            <Text className="text-gray-400 mt-1">{r.interests.join(", ")}</Text>
          </Pressable>
        ))}
      </ScrollView>
    </View>
  );
}
