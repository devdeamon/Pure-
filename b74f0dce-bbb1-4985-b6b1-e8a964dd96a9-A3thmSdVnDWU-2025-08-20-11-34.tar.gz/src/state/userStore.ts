import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface UserProfile {
  id: string;
  name: string;
  age: number;
  gender: "male" | "female" | "other";
  lookingFor: "male" | "female" | "both";
  purpose: "dating" | "friends" | "networking";
  photos: string[];
  city: string;
  interests: string[];
  bio?: string;
  isVerified: boolean;
}

interface UserState {
  isOnboarded: boolean;
  currentUser: UserProfile | null;
  telegramData: {
    id?: number;
    first_name?: string;
    last_name?: string;
    username?: string;
    photo_url?: string;
  } | null;
  
  // Actions
  setOnboarded: (onboarded: boolean) => void;
  setCurrentUser: (user: UserProfile) => void;
  setTelegramData: (data: any) => void;
  updateProfile: (updates: Partial<UserProfile>) => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set, get) => ({
      isOnboarded: false,
      currentUser: null,
      telegramData: null,

      setOnboarded: (onboarded) => set({ isOnboarded: onboarded }),
      
      setCurrentUser: (user) => set({ currentUser: user }),
      
      setTelegramData: (data) => set({ telegramData: data }),
      
      updateProfile: (updates) => {
        const currentUser = get().currentUser;
        if (currentUser) {
          set({ currentUser: { ...currentUser, ...updates } });
        }
      },
    }),
    {
      name: "user-storage",
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (state) => ({
        isOnboarded: state.isOnboarded,
        currentUser: state.currentUser,
        telegramData: state.telegramData,
      }),
    }
  )
);