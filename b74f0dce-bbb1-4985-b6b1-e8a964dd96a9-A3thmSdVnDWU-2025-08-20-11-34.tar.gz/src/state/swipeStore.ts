import { create } from "zustand";
import { UserProfile } from "./userStore";

export interface Match {
  id: string;
  user: UserProfile;
  matchedAt: Date;
  lastMessage?: {
    text: string;
    timestamp: Date;
    senderId: string;
  };
}

interface SwipeState {
  potentialMatches: UserProfile[];
  matches: Match[];
  currentCardIndex: number;
  dailySwipes: number;
  maxDailySwipes: number;
  hourlySwipes: number;
  maxHourlySwipes: number;
  lastResetHour?: number;
  
  // Actions
  setPotentialMatches: (matches: UserProfile[]) => void;
  addMatch: (match: Match) => void;
  incrementSwipes: () => void;
  resetDailySwipes: () => void;
  resetHourlySwipes: () => void;
  nextCard: () => void;
}

export const useSwipeStore = create<SwipeState>((set, get) => ({
  potentialMatches: [],
  matches: [],
  currentCardIndex: 0,
  dailySwipes: 0,
  maxDailySwipes: 50,
  hourlySwipes: 0,
  maxHourlySwipes: 20,
  lastResetHour: undefined,

  setPotentialMatches: (matches) => set({ potentialMatches: matches }),
  
  addMatch: (match) => {
    const matches = get().matches;
    set({ matches: [...matches, match] });
  },
  
  incrementSwipes: () => {
    const now = new Date();
    const hourKey = now.getUTCFullYear()*1000000 + (now.getUTCMonth()+1)*10000 + now.getUTCDate()*100 + now.getUTCHours();
    if (get().lastResetHour !== hourKey) {
      set({ hourlySwipes: 0, lastResetHour: hourKey });
    }
    set({
      dailySwipes: get().dailySwipes + 1,
      hourlySwipes: get().hourlySwipes + 1,
    });
  },
  
  resetDailySwipes: () => set({ dailySwipes: 0 }),
  resetHourlySwipes: () => set({ hourlySwipes: 0 }),
  
  nextCard: () => {
    const currentIndex = get().currentCardIndex;
    set({ currentCardIndex: currentIndex + 1 });
  },
}));