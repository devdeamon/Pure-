import { create } from "zustand";
import { persist, createJSONStorage } from "zustand/middleware";
import AsyncStorage from "@react-native-async-storage/async-storage";

export type Language = "en" | "ru";

interface FiltersState {
  gender?: "male" | "female" | "other";
  ageRange: [number, number];
  radiusKm: number;
  purpose?: "dating" | "friends" | "networking";
  interests: string[];
  verifiedOnly: boolean;
  ghostMode: boolean;
}

interface EntitlementsState {
  coins: number;
  hasSub: boolean;
  boostUntil?: number | null;
}

interface AppState {
  language: Language;
  isLanguageDetected: boolean;
  filters: FiltersState;
  entitlements: EntitlementsState;
  setLanguage: (lang: Language) => void;
  detectLanguage: () => void;
  setFilters: (p: Partial<FiltersState>) => void;
  resetFilters: () => void;
  spendCoin: (n?: number) => boolean;
  grantCoins: (n: number) => void;
  startBoost: (durationMinutes: number) => void;
  setSubscription: (active: boolean) => void;
}

function getInitialLanguage(): Language {
  // Try to detect from Telegram WebApp
  if (typeof window !== "undefined" && window.Telegram?.WebApp) {
    const telegramLang = window.Telegram.WebApp.initDataUnsafe.user?.language_code;
    if (telegramLang?.startsWith("ru")) {
      return "ru";
    }
  }
  
  // Fallback to browser locale
  if (typeof navigator !== "undefined") {
    const browserLang = navigator.language || (navigator as any).userLanguage;
    if (browserLang?.startsWith("ru")) {
      return "ru";
    }
  }
  
  return "en";
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      language: "en",
      isLanguageDetected: false,
      filters: {
        gender: undefined,
        ageRange: [18, 35],
        radiusKm: 25,
        purpose: undefined,
        interests: [],
        verifiedOnly: false,
        ghostMode: false,
      },
      entitlements: {
        coins: 0,
        hasSub: false,
        boostUntil: null,
      },
      setLanguage: (lang) => set({ language: lang }),
      detectLanguage: () => {
        if (!get().isLanguageDetected) {
          const detectedLang = getInitialLanguage();
          set({ language: detectedLang, isLanguageDetected: true });
        }
      },
      setFilters: (p) => set({ filters: { ...get().filters, ...p } }),
      resetFilters: () => set({
        filters: {
          gender: undefined,
          ageRange: [18, 35],
          radiusKm: 25,
          purpose: undefined,
          interests: [],
          verifiedOnly: false,
          ghostMode: false,
        },
      }),
      spendCoin: (n = 1) => {
        const ent = get().entitlements;
        if (ent.coins >= n) {
          set({ entitlements: { ...ent, coins: ent.coins - n } });
          return true;
        }
        return false;
      },
      grantCoins: (n) => set({ entitlements: { ...get().entitlements, coins: get().entitlements.coins + n } }),
      startBoost: (minutes) => {
        const until = Date.now() + minutes * 60 * 1000;
        set({ entitlements: { ...get().entitlements, boostUntil: until } });
      },
      setSubscription: (active) => set({ entitlements: { ...get().entitlements, hasSub: active } }),
    }),
    {
      name: "app-storage",
      storage: createJSONStorage(() => AsyncStorage),
      partialize: (s) => ({ language: s.language, isLanguageDetected: s.isLanguageDetected, filters: s.filters, entitlements: s.entitlements }),
    }
  )
);
