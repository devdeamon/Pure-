import { useEffect, useState } from "react";
import { telegramWebApp } from "../utils/telegram";

export interface TelegramTheme {
  bg_color: string;
  text_color: string;
  hint_color: string;
  link_color: string;
  button_color: string;
  button_text_color: string;
  secondary_bg_color: string;
}

export function useTelegramTheme() {
  const [theme, setTheme] = useState<TelegramTheme>({
    bg_color: "#000000",
    text_color: "#ffffff",
    hint_color: "#666666",
    link_color: "#ff4458",
    button_color: "#ff4458",
    button_text_color: "#ffffff",
    secondary_bg_color: "#1a1a1a",
  });

  const [colorScheme, setColorScheme] = useState<"light" | "dark">("dark");

  useEffect(() => {
    if (telegramWebApp.isAvailable()) {
      const telegramTheme = telegramWebApp.getThemeParams();
      const scheme = telegramWebApp.getColorScheme();
      
      setColorScheme(scheme);
      
      // Map Telegram theme to our theme
      setTheme({
        bg_color: telegramTheme.bg_color || "#000000",
        text_color: telegramTheme.text_color || "#ffffff",
        hint_color: telegramTheme.hint_color || "#666666",
        link_color: telegramTheme.link_color || "#ff4458",
        button_color: telegramTheme.button_color || "#ff4458",
        button_text_color: telegramTheme.button_text_color || "#ffffff",
        secondary_bg_color: telegramTheme.secondary_bg_color || "#1a1a1a",
      });
    }
  }, []);

  return {
    theme,
    colorScheme,
    isDark: colorScheme === "dark",
  };
}