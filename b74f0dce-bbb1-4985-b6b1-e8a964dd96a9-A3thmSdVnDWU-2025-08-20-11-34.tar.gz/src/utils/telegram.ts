// Telegram WebApp SDK types and utilities
declare global {
  interface Window {
    Telegram?: {
      WebApp: {
        initData: string;
        initDataUnsafe: {
          user?: {
            id: number;
            first_name: string;
            last_name?: string;
            username?: string;
            language_code?: string;
            photo_url?: string;
            is_premium?: boolean;
          };
          chat?: {
            id: number;
            type: string;
            title?: string;
            username?: string;
          };
          start_param?: string;
          auth_date: number;
          hash: string;
        };
        version: string;
        platform: string;
        colorScheme: "light" | "dark";
        themeParams: {
          bg_color?: string;
          text_color?: string;
          hint_color?: string;
          link_color?: string;
          button_color?: string;
          button_text_color?: string;
          secondary_bg_color?: string;
        };
        isExpanded: boolean;
        viewportHeight: number;
        viewportStableHeight: number;
        headerColor: string;
        backgroundColor: string;
        isClosingConfirmationEnabled: boolean;
        
        // Methods
        ready(): void;
        expand(): void;
        close(): void;
        enableClosingConfirmation(): void;
        disableClosingConfirmation(): void;
        setHeaderColor(color: string): void;
        setBackgroundColor(color: string): void;
        
        // Main Button
        MainButton: {
          text: string;
          color: string;
          textColor: string;
          isVisible: boolean;
          isActive: boolean;
          isProgressVisible: boolean;
          setText(text: string): void;
          onClick(callback: () => void): void;
          offClick(callback: () => void): void;
          show(): void;
          hide(): void;
          enable(): void;
          disable(): void;
          showProgress(leaveActive?: boolean): void;
          hideProgress(): void;
          setParams(params: {
            text?: string;
            color?: string;
            text_color?: string;
            is_active?: boolean;
            is_visible?: boolean;
          }): void;
        };
        
        // Back Button
        BackButton: {
          isVisible: boolean;
          onClick(callback: () => void): void;
          offClick(callback: () => void): void;
          show(): void;
          hide(): void;
        };
        
        // Haptic Feedback
        HapticFeedback: {
          impactOccurred(style: "light" | "medium" | "heavy" | "rigid" | "soft"): void;
          notificationOccurred(type: "error" | "success" | "warning"): void;
          selectionChanged(): void;
        };
        
        // Events
        onEvent(eventType: string, eventHandler: () => void): void;
        offEvent(eventType: string, eventHandler: () => void): void;
        sendData(data: string): void;
        
        // Utils
        openLink(url: string, options?: { try_instant_view?: boolean }): void;
        openTelegramLink(url: string): void;
        showPopup(params: {
          title?: string;
          message: string;
          buttons?: Array<{
            id?: string;
            type?: "default" | "ok" | "close" | "cancel" | "destructive";
            text: string;
          }>;
        }, callback?: (buttonId: string) => void): void;
        showAlert(message: string, callback?: () => void): void;
        showConfirm(message: string, callback?: (confirmed: boolean) => void): void;
        showScanQrPopup(params: {
          text?: string;
        }, callback?: (text: string) => void): void;
        closeScanQrPopup(): void;
        readTextFromClipboard(callback?: (text: string) => void): void;
        requestWriteAccess(callback?: (granted: boolean) => void): void;
        requestContact(callback?: (granted: boolean, contact?: {
          contact: {
            phone_number: string;
            first_name: string;
            last_name?: string;
            user_id?: number;
          };
        }) => void): void;
      };
    };
  }
}

export interface TelegramUser {
  id: number;
  first_name: string;
  last_name?: string;
  username?: string;
  language_code?: string;
  photo_url?: string;
  is_premium?: boolean;
}

export interface TelegramChat {
  id: number;
  type: string;
  title?: string;
  username?: string;
}

export class TelegramWebApp {
  private static instance: TelegramWebApp;
  private webApp: any = null;
  private isInitialized = false;

  private constructor() {
    this.init();
  }

  public static getInstance(): TelegramWebApp {
    if (!TelegramWebApp.instance) {
      TelegramWebApp.instance = new TelegramWebApp();
    }
    return TelegramWebApp.instance;
  }

  private init() {
    if (typeof window !== "undefined" && window.Telegram?.WebApp) {
      this.webApp = window.Telegram.WebApp;
      this.webApp.ready();
      this.webApp.expand();
      this.isInitialized = true;
      
      // Set app theme
      this.webApp.setHeaderColor("#000000");
      this.webApp.setBackgroundColor("#000000");
    }
  }

  public isAvailable(): boolean {
    return this.isInitialized && this.webApp !== null;
  }

  public getUser(): TelegramUser | null {
    if (!this.isAvailable()) return null;
    return this.webApp.initDataUnsafe.user || null;
  }

  public getChat(): TelegramChat | null {
    if (!this.isAvailable()) return null;
    return this.webApp.initDataUnsafe.chat || null;
  }

  public getStartParam(): string | null {
    if (!this.isAvailable()) return null;
    return this.webApp.initDataUnsafe.start_param || null;
  }

  public getThemeParams() {
    if (!this.isAvailable()) return {};
    return this.webApp.themeParams;
  }

  public getColorScheme(): "light" | "dark" {
    if (!this.isAvailable()) return "dark";
    return this.webApp.colorScheme;
  }

  public showMainButton(text: string, onClick: () => void) {
    if (!this.isAvailable()) return;
    
    this.webApp.MainButton.setText(text);
    this.webApp.MainButton.onClick(onClick);
    this.webApp.MainButton.show();
  }

  public hideMainButton() {
    if (!this.isAvailable()) return;
    this.webApp.MainButton.hide();
  }

  public showBackButton(onClick: () => void) {
    if (!this.isAvailable()) return;
    
    this.webApp.BackButton.onClick(onClick);
    this.webApp.BackButton.show();
  }

  public hideBackButton() {
    if (!this.isAvailable()) return;
    this.webApp.BackButton.hide();
  }

  public hapticFeedback(type: "impact" | "notification" | "selection", style?: string) {
    if (!this.isAvailable()) return;
    
    switch (type) {
      case "impact":
        this.webApp.HapticFeedback.impactOccurred(style || "medium");
        break;
      case "notification":
        this.webApp.HapticFeedback.notificationOccurred(style || "success");
        break;
      case "selection":
        this.webApp.HapticFeedback.selectionChanged();
        break;
    }
  }

  public showAlert(message: string, callback?: () => void) {
    if (!this.isAvailable()) {
      alert(message);
      callback?.();
      return;
    }
    
    this.webApp.showAlert(message, callback);
  }

  public showConfirm(message: string, callback?: (confirmed: boolean) => void) {
    if (!this.isAvailable()) {
      const result = confirm(message);
      callback?.(result);
      return;
    }
    
    this.webApp.showConfirm(message, callback);
  }

  public close() {
    if (!this.isAvailable()) return;
    this.webApp.close();
  }

  public openLink(url: string) {
    if (!this.isAvailable()) {
      window.open(url, "_blank");
      return;
    }
    
    this.webApp.openLink(url);
  }

  public sendData(data: any) {
    if (!this.isAvailable()) return;
    this.webApp.sendData(JSON.stringify(data));
  }
}

export const telegramWebApp = TelegramWebApp.getInstance();