import { useAppStore, Language } from "../state/appStore";

type Dict = { [key: string]: string | Dict };

const translations: Record<Language, Dict> = {
  en: {
    app: { name: "TeleDate" },
    tabs: { swipe: "Swipe", matches: "Matches", profile: "Profile" },
    common: { next: "Next", back: "Back", complete: "Complete" },
    onboarding: {
      title: "Welcome to TeleDate",
      subtitle: "Find meaningful connections in your local community",
      basicInfo: "Basic Info",
      tellUs: "Tell us about yourself",
      name: "Name",
      age: "Age",
      gender: "Gender",
      lookingFor: "Looking For",
      who: "Who are you interested in meeting?",
      genderPref: "Gender Preference",
      men: "Men",
      women: "Women",
      both: "Both",
      purpose: "Purpose",
      photos: "Photos",
      addPhotosHint: "Add up to 6 photos",
      addPhoto: "Add Photo",
      location: "Location",
      city: "City",
      useCurrent: "Use current location",
      errorRequired: "Please fill in all required fields",
    },
    swipe: {
      counter: "{used}/{max} swipes",
      like: "LIKE",
      pass: "PASS",
      emptyTitle: "No more profiles",
      emptySubtitle: "Check back later for new people in your area",
      limitReached: "You have reached your daily swipe limit. Upgrade to continue swiping!",
    },
    matches: {
      title: "Matches",
      emptyTitle: "No matches yet",
      emptySubtitle: "Start swiping to find your perfect match!",
      count_one: "{n} match",
      count_few: "{n} matches",
      count_many: "{n} matches",
    },
    time: {
      justNow: "Just now",
      hours_one: "{n}h ago",
      hours_few: "{n}h ago",
      hours_many: "{n}h ago",
      days_one: "{n}d ago",
      days_few: "{n}d ago",
      days_many: "{n}d ago",
    },
    chat: {
      matchedWith: "You matched with {name}!",
      placeholder: "Type a message...",
    },
    profile: {
      title: "Profile",
      noProfile: "No profile found",
      yearsOld: "{n} years old",
      matches: "Matches",
      dailySwipes: "Daily Swipes",
      aboutMe: "About Me",
      lookingFor: "Looking for {who}",
      purpose: "{purpose}",
      gender: "{gender}",
      interests: "Interests",
      bio: "Bio",
      edit: "Edit Profile",
      verify: "Get Verified",
      signOut: "Sign Out",
      language: "Language",
      russian: "Russian",
      english: "English",
    },
    filters: {
      title: "Filters",
      subtitle: "Refine your recommendations",
      age: "Age Range",
      radius: "Radius",
      verifiedOnly: "Only verified profiles (Pro)",
      ghostMode: "Ghost mode (hide city/round area)",
      reset: "Reset",
      apply: "Apply",
      pro_radius_hint: "Fine radius under 5km is a Pro feature",
    },
    paywall: {
      title: "Upgrade to Pro",
      subtitle: "More swipes, Ghost mode, Pro filters",
      buyCoins: "Buy coins",
      buySub: "Go Pro monthly",
      buyBoost: "Activate Boost",
      superlike: "Superlike",
      boostActive: "Boost active",
    },
    verify: {
      title: "Verification",
      subtitle: "Take a short selfie sequence to verify",
      start: "Start",
      blink: "Blink",
      turn: "Turn your head",
      submitting: "Submitting...",
      success: "Verified!",
      fail: "Could not verify",
    },
    report: {
      title: "Report or Block",
      report: "Report",
      block: "Block",
      reason: "Choose a reason",
      sent: "Report sent",
    },
    hubs: {
      title: "Rooms",
      tech: "Tech",
      music: "Music",
      sport: "Sport",
      startups: "Startups",
      darkFriday: "Dark Friday",
      inRoom: "Room mode",
      leave: "Leave room",
    },
  },
  ru: {
    app: { name: "TeleDate" },
    tabs: { swipe: "Свайпы", matches: "Мэтчи", profile: "Профиль" },
    common: { next: "Далее", back: "Назад", complete: "Готово" },
    onboarding: {
      title: "Добро пожаловать в TeleDate",
      subtitle: "Находите знакомства в локальном комьюнити",
      basicInfo: "Основная информация",
      tellUs: "Расскажите о себе",
      name: "Имя",
      age: "Возраст",
      gender: "Пол",
      lookingFor: "Кого ищете",
      who: "Кого хотите встретить?",
      genderPref: "Предпочтение по полу",
      men: "Мужчины",
      women: "Женщины",
      both: "Оба",
      purpose: "Цель",
      photos: "Фото",
      addPhotosHint: "Добавьте до 6 фото",
      addPhoto: "Добавить фото",
      location: "Локация",
      city: "Город",
      useCurrent: "Использовать текущую геолокацию",
      errorRequired: "Заполните обязательные поля",
    },
    swipe: {
      counter: "{used}/{max} свайпов",
      like: "ЛАЙК",
      pass: "ПРОПУСТИТЬ",
      emptyTitle: "Профили закончились",
      emptySubtitle: "Загляните позже — появятся новые люди рядом",
      limitReached: "Вы исчерпали дневной лимит свайпов. Оформите подписку, чтобы продолжить!",
    },
    matches: {
      title: "Мэтчи",
      emptyTitle: "Пока нет мэтчей",
      emptySubtitle: "Начните свайпать, чтобы найти совпадение!",
      count_one: "{n} мэтч",
      count_few: "{n} мэтча",
      count_many: "{n} мэтчей",
    },
    time: {
      justNow: "Только что",
      hours_one: "{n} ч назад",
      hours_few: "{n} ч назад",
      hours_many: "{n} ч назад",
      days_one: "{n} дн назад",
      days_few: "{n} дн назад",
      days_many: "{n} дн назад",
    },
    chat: {
      matchedWith: "У вас мэтч с {name}!",
      placeholder: "Напишите сообщение...",
    },
    profile: {
      title: "Профиль",
      noProfile: "Профиль не найден",
      yearsOld: "{n} лет",
      matches: "Мэтчи",
      dailySwipes: "Дневной лимит",
      aboutMe: "О себе",
      lookingFor: "Ищу: {who}",
      purpose: "{purpose}",
      gender: "{gender}",
      interests: "Интересы",
      bio: "Био",
      edit: "Редактировать профиль",
      verify: "Пройти верификацию",
      signOut: "Выйти",
      language: "Язык",
      russian: "Русский",
      english: "Английский",
    },
    filters: {
      title: "Фильтры",
      subtitle: "Уточните рекомендации",
      age: "Возраст",
      radius: "Радиус",
      verifiedOnly: "Только верифицированные (Pro)",
      ghostMode: "Призрачный режим (скрыть город)",
      reset: "Сбросить",
      apply: "Применить",
      pro_radius_hint: "Точный радиус ниже 5 км — Pro функция",
    },
    paywall: {
      title: "Перейти на Pro",
      subtitle: "Больше свайпов, призрачный режим, Pro-фильтры",
      buyCoins: "Купить монеты",
      buySub: "Оформить подписку",
      buyBoost: "Активировать Boost",
      superlike: "Суперлайк",
      boostActive: "Boost активен",
    },
    verify: {
      title: "Верификация",
      subtitle: "Короткая селфи-проверка",
      start: "Начать",
      blink: "Моргните",
      turn: "Поверните голову",
      submitting: "Отправка...",
      success: "Верифицировано!",
      fail: "Не удалось подтвердить",
    },
    report: {
      title: "Жалоба или блокировка",
      report: "Пожаловаться",
      block: "Заблокировать",
      reason: "Выберите причину",
      sent: "Жалоба отправлена",
    },
    hubs: {
      title: "Комнаты",
      tech: "Тех",
      music: "Музыка",
      sport: "Спорт",
      startups: "Стартапы",
      darkFriday: "Темная пятница",
      inRoom: "Режим комнаты",
      leave: "Выйти",
    },
  },
};

function interpolateParams(str: string, params?: Record<string, string | number>) {
  if (!params) return str;
  return str.replace(/\{(.*?)\}/g, (_, k) => String(params[k] ?? ""));
}

export function tPath(lang: Language, path: string, params?: Record<string, string | number>): string {
  const parts = path.split(".");
  let node: any = translations[lang];
  for (const p of parts) {
    node = node?.[p];
    if (!node) break;
  }
  if (typeof node === "string") return interpolateParams(node, params);
  return path;
}

export function pluralForm(lang: Language, n: number): "one" | "few" | "many" {
  if (lang === "ru") {
    const mod10 = n % 10;
    const mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return "one";
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 12 || mod100 > 14)) return "few";
    return "many";
  }
  return n === 1 ? "one" : n >= 2 && n <= 4 ? "few" : "many";
}

export function tpPath(lang: Language, base: string, n: number, params?: Record<string, string | number>): string {
  const form = pluralForm(lang, n);
  const key = `${base}_${form}`;
  return tPath(lang, key, { ...params, n });
}

export function timeAgo(lang: Language, date: Date): string {
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const hours = Math.floor(diffMs / (1000 * 60 * 60));
  if (hours < 1) return tPath(lang, "time.justNow");
  if (hours < 24) return tpPath(lang, "time.hours", hours, { n: hours });
  const days = Math.floor(hours / 24);
  return tpPath(lang, "time.days", days, { n: days });
}

export function useI18n() {
  const lang = useAppStore((s) => s.language);
  return {
    lang,
    t: (key: string, params?: Record<string, string | number>) => tPath(lang, key, params),
    tp: (base: string, n: number, params?: Record<string, string | number>) => tpPath(lang, base, n, params),
    timeAgo: (d: Date) => timeAgo(lang, d),
  };
}
