import { telegramWebApp } from "./telegram";

export interface DeepLinkParams {
  action?: string;
  userId?: string;
  matchId?: string;
  chatId?: string;
}

export class DeepLinkHandler {
  private static instance: DeepLinkHandler;

  private constructor() {}

  public static getInstance(): DeepLinkHandler {
    if (!DeepLinkHandler.instance) {
      DeepLinkHandler.instance = new DeepLinkHandler();
    }
    return DeepLinkHandler.instance;
  }

  public parseStartParam(startParam: string): DeepLinkParams {
    const params: DeepLinkParams = {};
    
    if (!startParam) return params;

    try {
      // Parse different deep link formats
      if (startParam.startsWith("user_")) {
        params.action = "viewProfile";
        params.userId = startParam.replace("user_", "");
      } else if (startParam.startsWith("match_")) {
        params.action = "openMatch";
        params.matchId = startParam.replace("match_", "");
      } else if (startParam.startsWith("chat_")) {
        params.action = "openChat";
        params.chatId = startParam.replace("chat_", "");
      } else {
        // Try to parse as JSON
        const decoded = decodeURIComponent(startParam);
        const parsed = JSON.parse(decoded);
        Object.assign(params, parsed);
      }
    } catch (error) {
      console.warn("Failed to parse start param:", startParam, error);
    }

    return params;
  }

  public handleDeepLink(params: DeepLinkParams, navigation: any) {
    switch (params.action) {
      case "viewProfile":
        if (params.userId) {
          // Navigate to user profile
          navigation.navigate("Profile", { userId: params.userId });
        }
        break;
        
      case "openMatch":
        if (params.matchId) {
          // Navigate to match screen and highlight specific match
          navigation.navigate("Matches", { highlightMatch: params.matchId });
        }
        break;
        
      case "openChat":
        if (params.chatId) {
          // Navigate directly to chat
          navigation.navigate("Chat", { chatId: params.chatId });
        }
        break;
        
      default:
        // Default action - go to main screen
        navigation.navigate("MainTabs");
        break;
    }
  }

  public generateShareLink(action: string, data: any): string {
    const params = { action, ...data };
    const encoded = encodeURIComponent(JSON.stringify(params));
    return `https://t.me/your_bot_username/app?startapp=${encoded}`;
  }

  public shareProfile(userId: string, userName: string) {
    const link = this.generateShareLink("viewProfile", { userId });
    const text = `Check out ${userName} on TeleDate!`;
    
    if (telegramWebApp.isAvailable()) {
      telegramWebApp.openLink(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`);
    } else {
      // Fallback for web
      navigator.share?.({ title: text, url: link }) || 
      navigator.clipboard?.writeText(`${text} ${link}`);
    }
  }

  public shareMatch(matchId: string, userName: string) {
    const link = this.generateShareLink("openMatch", { matchId });
    const text = `I matched with ${userName} on TeleDate! 🎉`;
    
    if (telegramWebApp.isAvailable()) {
      telegramWebApp.openLink(`https://t.me/share/url?url=${encodeURIComponent(link)}&text=${encodeURIComponent(text)}`);
    }
  }
}

export const deepLinkHandler = DeepLinkHandler.getInstance();